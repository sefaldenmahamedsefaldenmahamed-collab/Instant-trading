"""Ed25519 request signer for Binance API keys (SIGNED endpoints).

Why: Binance shows the HMAC secret only once at creation — many users lose it.
With Ed25519 keys the user generates the key pair themselves (e.g. with the
bundled ed25519-keygen.html tool), registers only the PUBLIC key with Binance,
and the private part never leaves their possession. No secret is ever shown
"once" by Binance — nothing to lose.

Official rules (binance-spot-api-docs, REST API → Ed25519 Keys):
- Signature payload = the (percent-encoded) query string — our client sends all
  params in the query string, so payload = qs exactly as built.
- Signature = Ed25519 sig over the payload, encoded as **base64**, then
  percent-encoded when placed in the URL (we do that in the client).

Accepted private key formats for BINANCE_API_SECRET (auto-detected):
1. Raw 32-byte seed, base64  (exactly what ed25519-keygen.html exports)
2. Raw 32-byte seed, hex     (64 hex chars)
3. PKCS#8 PEM  ("-----BEGIN PRIVATE KEY-----")
4. PKCS#8 DER, base64        (48 bytes for Ed25519)
"""
from __future__ import annotations

import base64
import binascii
import logging

log = logging.getLogger("binance.ed25519")

try:  # lazily validated; hard failure only when actually used
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import (
        load_der_private_key,
        load_pem_private_key,
    )

    _HAS_CRYPTO = True
except Exception:  # pragma: no cover
    _HAS_CRYPTO = False


class Ed25519Signer:
    """Loads an Ed25519 private key from a flexible textual form and signs payloads."""

    def __init__(self, secret_text: str) -> None:
        if not _HAS_CRYPTO:
            raise RuntimeError(
                "حزمة cryptography غير مثبتة — أضفها في requirements.txt أو استخدم BINANCE_AUTH=hmac"
            )
        self._key = self._load(secret_text.strip())

    # ── loading ───────────────────────────────────────────────────────────
    @staticmethod
    def _load(text: str) -> "Ed25519PrivateKey":
        # 1) PEM
        if "-----BEGIN" in text:
            key = load_pem_private_key(text.encode(), password=None)
            if not isinstance(key, Ed25519PrivateKey):
                raise ValueError("المفتاح الموجود ليس Ed25519")
            return key

        # 2) hex seed — افحصه أولاً لأن أحرف hex صالحة أيضاً كـ base64
        if len(text) == 64 and all(c in "0123456789abcdefABCDEF" for c in text):
            return Ed25519PrivateKey.from_private_bytes(bytes.fromhex(text))

        # 3) base64: بذرة خام (32 بايت) أو DER بصيغة PKCS#8 (48 بايت)
        try:
            raw = base64.b64decode(text, validate=True)
        except (binascii.Error, ValueError):
            raw = b""

        if len(raw) == 32:
            return Ed25519PrivateKey.from_private_bytes(raw)

        if len(raw) == 48:  # PKCS#8 DER (base64) — Ed25519
            try:
                key = load_der_private_key(raw, password=None)
                if not isinstance(key, Ed25519PrivateKey):
                    raise ValueError("المفتاح الموجود ليس Ed25519")
                return key
            except Exception:
                pass  # DER تالف → ارفض في الأسفل برسالة واضحة

        raise ValueError(
            "صيغة المفتاح الخاص غير مفهومة — استخدم القيمة الأساسية (base64) من ed25519-keygen.html"
        )

    # ── signing ───────────────────────────────────────────────────────────
    def sign_b64(self, payload: str) -> str:
        sig: bytes = self._key.sign(payload.encode())
        return base64.b64encode(sig).decode()
