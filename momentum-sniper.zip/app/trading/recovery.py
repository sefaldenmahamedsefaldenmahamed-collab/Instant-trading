"""Recovery — إعادة بناء الصفقات اليتيمة بعد إعادة نشر/إعادة تشغيل.

المشكلة: الصفقات المفتوحة تعيش في ذاكرة العملية وقاعدة بيانات مؤقتة على Render،
وأي إعادة نشر تمسح الحالة — لكن العملات المشتراة تبقى في حساب Binance فعلياً.

الحل عند الإقلاع (testnet/live فقط):
1) نجلب الأرصدة الحقيقية من المنصة (GET /api/v3/account).
2) لكل أصل غير USDT يملكه الحساب: نطلب سجل صفقاتك الفعلية (GET /api/v3/myTrades).
3) إن وُجدت صفقات شراء حديثة (خلال RECOVERY_MAX_AGE_DAYS) نحسب:
     • متوسط سعر الدخول الموزون (شامل عمولة USDT إن وجدت)
     • توقيت آخر شراء
   ونبني Position كاملة تستأنف إدارتها: سلّم الأهداف + الوقف المتحرك + الوقف الصارم
   (مع حماية RECOVERY_SKIP_STOP كي لا تُصفّى فوراً إن كانت تحت الوقف).
4) الأصول بلا تاريخ شراء (هدايا/تحويلات يدوية) تُتجاهل — لا ندير ما لم نشترِه.
"""
from __future__ import annotations

import logging
import time

from app.config import CFG
from app.exchange.binance_client import BinanceError
from app.trading.position import Position

log = logging.getLogger("recovery")


async def recover_orphans(engine) -> list[Position]:
    """يفحص حساب Binance ويعيد بناء الصفقات التي اشتراها البوت سابقاً."""
    if not CFG.recover_orphans:
        log.info("recovery disabled (RECOVER_ORPHANS=false)")
        return []

    bal: dict[str, float] = await engine.broker.get_balance()   # asset → free (>0 فقط)
    tracked = {p.symbol for p in engine.positions.values()}
    now_ms = time.time() * 1000
    max_age_ms = CFG.recovery_max_age_days * 86400 * 1000
    recovered: list[Position] = []

    for asset, free in sorted(bal.items()):
        if asset == CFG.quote_asset or free <= 0:
            continue
        sym = f"{asset}{CFG.quote_asset}"
        if sym in tracked or sym in CFG.blacklist \
                or any(sym.endswith(p) for p in CFG.leveraged_patterns):
            continue
        if not engine.client.is_spot_usdt(sym):
            log.info("recovery: %s ليس زوج %s متاحاً للتداول — تجاهل", sym, CFG.quote_asset)
            continue

        # ── سجل الصفقات الفعلية لهذا الرمز ──
        try:
            trades = await engine.client.my_trades(sym, limit=200)
        except BinanceError as e:
            log.warning("recovery: myTrades %s فشل: %s", sym, e)
            continue

        buys = [t for t in trades if t.get("isBuyer")]
        if not buys:
            log.info("recovery: يوجد رصيد %s لكن بلا تاريخ شراء (يدوي/هدايا) — تجاهل", sym)
            continue
        recent = [t for t in buys if now_ms - int(t["time"]) <= max_age_ms]
        if not recent:
            log.info("recovery: صفقات %s أقدم من %s يوم — تجاهل", sym, CFG.recovery_max_age_days)
            continue

        qty_bought = sum(float(t["qty"]) for t in recent)
        quote_spent = sum(float(t["quoteQty"]) for t in recent)
        fees_quote = sum(float(t["commission"]) for t in recent
                         if t.get("commissionAsset") == CFG.quote_asset)
        if qty_bought <= 0:
            continue
        avg_entry = (quote_spent + fees_quote) / qty_bought
        last_buy_ts = max(int(t["time"]) for t in recent) / 1000.0
        if avg_entry <= 0:
            continue

        # ── السعر الحالي: للتحقق من معقولية الدخول وضبط القيمة السوقية ──
        try:
            mark = float((await engine.client.tickers([sym]))[sym]["lastPrice"])
        except Exception:
            mark = 0.0
        if mark > 0 and (avg_entry / mark > 10.0 or avg_entry / mark < 0.1):
            log.warning("recovery: سعر دخول %s غير منطقي (%.8g مقابل السوق %.8g) — اعتمدنا سعر السوق",
                        sym, avg_entry, mark)
            avg_entry = mark

        # ── الكمية الفعلية القابلة للإدارة (المتاحة الآن) مع تقريب stepSize ──
        step = engine.client.symbol_filters(sym).get("stepSize", 0.0)
        qty = engine.client.round_step(free, step) or free

        # غبار أقل من الحد الأدنى؟ لا معنى لإدارة صفقة لا يمكن بيعها
        value = qty * (mark or avg_entry)
        if value < CFG.min_notional_usdt:
            log.info("recovery: قيمة %s المتوفرة %.4f USDT أقل من الحد الأدنى — غبار، تجاهل", sym, value)
            continue

        pos = Position(
            symbol=sym, base=asset, qty=qty, qty_initial=qty,
            entry_price=avg_entry, entry_ts=last_buy_ts,
            mode=getattr(engine.broker, "mode", CFG.mode),
            score_at_entry=0.0,
            reasons=["🔄 استعادة تلقائية من سجل صفقات Binance بعد إعادة النشر"],
            sources=["recovered"],
            recovered=True,
        )
        pos.update_mark(mark or avg_entry)
        recovered.append(pos)
        log.info("recovery: أُعيد بناء %s — كمية %.6g، دخول %.8g، آخر شراء %s",
                 sym, qty, avg_entry, time.strftime("%Y-%m-%d %H:%M", time.localtime(last_buy_ts)))

    return recovered
