"""Self Keep-Alive pinger — يمنع Render المجاني من إسباغ الخدمة (spin-down).

الفكرة (نفس آلية بوت العقود لدى المستخدم):
- خطة Render المجانية تُسبك الخدمة بعد 15 دقيقة بلا طلبات HTTP واردة.
- مهمة خلفية ترسل GET إلى /health كل KEEPALIVE_INTERVAL_SEC (افتراضي 600 ثانية = 10 دقائق).
- نقاط النبض:
    1) RENDER_EXTERNAL_URL/health  ← Render يضبط هذا المتغير تلقائياً في كل نشر.
       النبض عبر العنوان العام هو ما يَعُدّ "زيارة" لدى Render ويمنع النوم.
    2) http://127.0.0.1:${PORT}/health ← فحص ذاتي داخلي (يؤكد أن الخادم حي فعلاً).
    3) أي عناوين إضافية من KEEPALIVE_URLS (مفصولة بفواصل) — اختياري.

ملاحظة: النبض الداخلي (127.0.0.1) وحده لا يمنع النوم — Render يحسب الزيارات
على العنوان العام فقط، ولهذا نرسل الاثنين معاً.
"""
from __future__ import annotations

import asyncio
import logging
import os

import aiohttp

from app.config import CFG

log = logging.getLogger("keepalive")


def keepalive_urls() -> list[str]:
    """يبني قائمة عناوين النبض: الخارجي (إن وُجد) + الداخلي + الإضافيات."""
    urls: list[str] = []
    ext = os.environ.get("RENDER_EXTERNAL_URL", "").strip()
    if ext:
        urls.append(ext.rstrip("/") + "/health")
    urls.append(f"http://127.0.0.1:{CFG.port}/health")
    for extra in CFG.keepalive_urls.split(","):
        u = extra.strip()
        if u and u not in urls:
            urls.append(u)
    return urls


async def run_keepalive() -> None:
    """حلقة النبض: تعمل طوال عمر العملية، ولا تفعل شيئاً إن كانت معطلة."""
    if not CFG.keepalive_enabled:
        log.info("💓 Keep-Alive معطّل (KEEPALIVE_ENABLED=false)")
        return

    urls = keepalive_urls()
    interval = max(60, CFG.keepalive_interval_sec)  # أقل من ذلك لا معنى له
    log.info("💓 Keep-Alive نشط كل %s ثانية → %s", interval, urls)

    timeout = aiohttp.ClientTimeout(total=15)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        while True:
            await asyncio.sleep(interval)
            for u in urls:
                try:
                    async with session.get(u) as r:
                        body = await r.text()
                        if r.status == 200:
                            log.info("💓 نبضة OK %s → %s", u, body[:120])
                        else:
                            log.warning("💓 نبضة استجابة %s من %s → %s", r.status, u, body[:120])
                except Exception as e:
                    log.warning("💓 نبضة فاشلة %s (%s)", u, e)


_keepalive_task: asyncio.Task | None = None


def start_keepalive() -> asyncio.Task:
    global _keepalive_task
    _keepalive_task = asyncio.create_task(run_keepalive(), name="keepalive")
    return _keepalive_task


def stop_keepalive() -> None:
    global _keepalive_task
    if _keepalive_task and not _keepalive_task.done():
        _keepalive_task.cancel()
    _keepalive_task = None
